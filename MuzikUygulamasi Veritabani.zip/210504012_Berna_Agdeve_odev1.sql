﻿CREATE DATABASE MuzikKutuphanesi;--veritabanını oluşturudum..
--daha sonra tabloları aluşturuyorum...
-- Albümler tablosu
CREATE TABLE Albümler (
  albüm_id INT PRIMARY KEY,
  albüm_adı VARCHAR(100),
  yayın_tarihi DATE,
  kapak_resmi VARCHAR(100)
);
-- Sanatçılar tablosu
CREATE TABLE Sanatçılar (
  sanatçı_id INT PRIMARY KEY,
  sanatçı_adı VARCHAR(255),
  doğum_tarihi DATE,
  ülke VARCHAR(100)
);
-- Türler tablosu
CREATE TABLE Türler (
  tür_id INT PRIMARY KEY,
  tür_adı VARCHAR(100)
);
-- Şarkılar tablosu
CREATE TABLE Şarkılar (
  şarkı_id INT PRIMARY KEY,
  şarkı_adı VARCHAR(100),
  süre TIME,
  yayın_tarihi DATE,
  albüm_id INT,
  sanatçı_id INT,
  tür_id INT,
  FOREIGN KEY (albüm_id) REFERENCES Albümler(albüm_id),
  FOREIGN KEY (sanatçı_id) REFERENCES Sanatçılar(sanatçı_id),
  FOREIGN KEY (tür_id) REFERENCES Türler(tür_id)
);

-- Kullanıcılar tablosu
CREATE TABLE Kullanıcılar (
  kullanıcı_id INT PRIMARY KEY,
  kullanıcı_adı VARCHAR(100),
  şifre VARCHAR(100),
  e_posta VARCHAR(100)
);
-- Çalma Listeleri tablosu
CREATE TABLE ÇalmaListeleri (
  liste_id INT PRIMARY KEY,
  liste_adı VARCHAR(100),
  kullanıcı_id INT,
  FOREIGN KEY (kullanıcı_id) REFERENCES Kullanıcılar(kullanıcı_id)
);
-- Üyelik tablosu
CREATE TABLE Üyelik (
  üyelik_id INT PRIMARY KEY,
  kullanıcı_id INT,
  üyelik_tipi VARCHAR(100),
  şarkı_sınırlama INT,
  FOREIGN KEY (kullanıcı_id) REFERENCES Kullanıcılar(kullanıcı_id)
);
-- Beğeniler tablosu
CREATE TABLE Beğeniler (
  beğeni_id INT PRIMARY KEY,
  kullanıcı_id INT,
  şarkı_id INT,
  beğeni_durumu VARCHAR(100),
  FOREIGN KEY (kullanıcı_id) REFERENCES Kullanıcılar(kullanıcı_id),
  FOREIGN KEY (şarkı_id) REFERENCES Şarkılar(şarkı_id)
);
-- Yorumlar tablosu
CREATE TABLE Yorumlar (
  yorum_id INT PRIMARY KEY,
  kullanıcı_id INT,
  şarkı_id INT,
  yorum_metni TEXT,
  yorum_tarihi DATE,
  FOREIGN KEY (kullanıcı_id) REFERENCES Kullanıcılar(kullanıcı_id),
  FOREIGN KEY (şarkı_id) REFERENCES Şarkılar(şarkı_id)
);
-- Favoriler tablosu
CREATE TABLE Favoriler (
  favori_id INT PRIMARY KEY,
  kullanıcı_id INT,
  şarkı_id INT,
  FOREIGN KEY (kullanıcı_id) REFERENCES Kullanıcılar(kullanıcı_id),
  FOREIGN KEY (şarkı_id) REFERENCES Şarkılar(şarkı_id)
); 
-- ÇalmaListesiŞarkıları tablosu
CREATE TABLE ÇalmaListesiŞarkıları (
çalma_listesi_şarkısı_id INT PRIMARY KEY,
liste_id INT,
şarkı_id INT,
FOREIGN KEY (liste_id) REFERENCES ÇalmaListeleri(liste_id),
FOREIGN KEY (şarkı_id) REFERENCES Şarkılar(şarkı_id)
);
-- Tablolara 10 adet kayıt eklenecek.....
--birinci kayıt
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (1, 'Karma', '1999-12-17', 'karma.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (1, 'Tarkan', '1972-10-17', 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (1, 'Pop');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (1, 'Şımarık', '00:03:55', '1999-12-17', 1, 1, 1);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (1, 'berna_yılmaz', 'password123', 'berna.yilmaz@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (1, 'Pop Hits', 1);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (1, 1, 'Premium', 1000);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (1, 1, 1, 'Beğenildi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (1, 1, 1, 'Harika şarkı!', '2023-06-01');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (1, 1, 1);
--ikinci kayıt
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (2, 'Biraz Pop Biraz Sezen', '1997-06-17', 'biraz_pop_biraz_sezen.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (2, 'Sezen Aksu', '1954-07-13', 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (2, 'Pop');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES(2, 'Geçer', '00:04:08', '1997-06-17', 2, 2, 2);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (2, 'ayse_yılmaz', 'password122', 'ayse.yilmaz@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (2, 'Pop Hits', 2);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (2, 2, 'Premium', 1000);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (2, 2, 2, 'Beğenildi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (2, 2, 2, 'güzel şarkı!', '2023-06-01');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (2, 2, 2);
--üçüncü kayıt ekleniyor
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (3, 'Deliler', '1995-09-25', 'deliler.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (3, 'Tarkan', '1972-10-17', 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (3, 'Pop');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (3, 'Şımarık', '00:03:56', '1995-09-25', 3, 3, 3);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (3, 'ayten_kaya', 'berna36', 'ayten_kaya@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (3, 'Party Mix', 3);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (3, 3, 'Standart', 500);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (3, 3, 3, 'Beğenilmedi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (3, 3, 3, 'biraz daha iyi olabilirdi!', '2023-05-30');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (3, 3, 3);
--dördüncü kayıt ekleniyor......
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (4, 'Thriller', '1982-11-20', 'thriller.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (4, 'Michael Jackson', '1958-06-29', 'ABD');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (4, 'hit');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (4, 'Billie Jean', '00:04:54', '1982-11-20', 4, 4, 4);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (4, 'john_doe', 'sifre...', 'john.doe@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (4, 'Favorite Hits', 4);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (4, 4, 'Standart', 2000);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (4, 4, 4, 'Beğenilmedi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (4, 4, 4, 'güzel değil!', '2023-05-29');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (4, 4, 4);
--beşinci kayıt ekleniyor............
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (5, 'Hayatı Tesbih Yapmışım', '2006-03-05', 'hayati_tesbih_yapmisim.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (5, 'Ferman Akgül', '1981-04-25', 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (5, 'Pop');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (5, 'Rüzgar', '21:04:25', '2006-03-05', 5, 5, 5);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (5, 'Melike_dere', 'Md0101', 'melikedere01@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (5, 'Türkçe Pop', 5);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (5, 5, 'Premium', 1500);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (5, 5, 5, 'Beğenildi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (5, 5, 5, 'Sevdiğim bir şarkı..', '2022-05-31');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (5, 5, 5);
--altıncı kayıt eklenecek
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (6, 'Back in Black', '1990-07-25', 'back_in_black.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (6, 'AC/DC', '1973-12-01', 'Avustralya');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (6, 'Rock');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (6, 'Back in Black', '00:04:15', '1990-07-25', 6, 6, 6);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (6, 'melektikan', 'MT3636', 'melektikan36@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (6, 'Rock Anthems', 6);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (6, 6, 'Standart', 2000);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (6, 6, 6, 'Beğenilmedi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (6, 6, 6, 'kötü bir şarkı', '2021-06-01');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (6, 6, 6);
--7. kayıt eklenecek.......
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (7, 'Düş Sokağı Sakinleri', '1986-10-01', 'dus_sokagi_sakinleri.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (7, 'Düş Sokağı Sakinleri','1966-06-01' , 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (7, 'Rock');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (7, 'Gece', '12:04:12', '1986-10-01', 7, 7, 7);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (7, 'bekiragdeve', 'BA3434', 'rbekiragdeve85@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (7, 'Türkçe Rock Seçkileri', 7);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (7, 7, 'Premium', 2000);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (7, 7, 7, 'Beğenilmedi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (7, 7, 7, 'çok kötü bir şarkı olmuş', '2020-06-28');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (7, 7, 7);
--8. kayıt eklenecek....
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (8, 'Greatest Hits', '2001-03-25', 'greatest_hits.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (8, 'Queen', '2003-12-28', 'İngiltere');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (8, 'hit');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (8, 'Bohemian Rhapsody', '10:05:55', '2001-03-25', 8, 8, 8);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (8, 'esramecu', 'EM3634', 'esra2136@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (8, 'Hit Songs', 8);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (8, 8, 'Standart', 2000);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (8, 8, 8, 'Beğenildi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (8, 8, 8, 'sanatçının en iyi şarkısı!', '1999-08-21');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (8, 8, 8);
--9. KAYIT EKLENECEK
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (9, 'Anlatamıyorum', '2001-12-27', 'anlatamiyorum.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (9, 'Duman', '1993-12-27', 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (9, 'Rock');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (9, 'Senden Daha Güzel', '20:33:28', '2001-12-27', 9, 9, 9);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (9, 'eminagdeve', 'EA343434', 'eminn23@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (9, 'Rock Anthems', 9);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (9, 9, 'Premium', 2195);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (9, 9, 9, 'Beğenilmedi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (9, 9, 9, 'Dumanın en kötü şarkılarından biri!', '2005-04-15');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (9, 9, 9);
--10. kayıt ekleniyor.......
INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
VALUES (10, 'Dertler Benim Olsun', '1984-12-05', 'dertler_benim_olsun.jpg');
INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
VALUES (10, 'Müslüm Gürses', '1973-05-07', 'Türkiye');
INSERT INTO Türler (tür_id, tür_adı)
VALUES (10, 'Arabesk');
INSERT INTO Şarkılar (şarkı_id, şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (10, 'Dünya Dönüyor', '13:25:59', '1984-12-05', 10, 10, 10);
INSERT INTO Kullanıcılar (kullanıcı_id, kullanıcı_adı, şifre, e_posta)
VALUES (10, 'bilalkılıc', 'BK343434', 'bilalkilic00@gmail.com');
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (10, 'Müslüm Gürses Şarkıları', 10);
INSERT INTO Üyelik (üyelik_id, kullanıcı_id, üyelik_tipi, şarkı_sınırlama)
VALUES (10, 10, 'Standart', 5010);
INSERT INTO Beğeniler (beğeni_id, kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (10, 10, 10, 'Beğenildi');
INSERT INTO Yorumlar (yorum_id, kullanıcı_id, şarkı_id, yorum_metni, yorum_tarihi)
VALUES (10, 10, 10, 'Müslüm Gürsesin efsanevi şarkılarından biri!', '1996-05-17');
INSERT INTO Favoriler (favori_id, kullanıcı_id, şarkı_id)
VALUES (10, 10, 10);
--1.Belirli bir albümdeki tüm şarkıları alfabetik olarak listeleyen sql kodu 
SELECT ş.şarkı_adı
FROM Şarkılar ş
FULL JOIN Albümler a ON ş.albüm_id = a.albüm_id
WHERE a.albüm_adı = 'Dertler Benim Olsun' --hangi albümdeki şarkıların sıralanmasını istiyorsak albümün ismini buraya yazacağız 
ORDER BY ş.şarkı_adı ASC;                 --örnegin burda Dertler Benim Olsun albümündeki şarkıları sıralıyor
--2.Belirli bir sanatçının tüm şarkılarını albümlerine göre gruplandırarak listeleyen sql kodu
SELECT Albümler.albüm_adı, Şarkılar.şarkı_adı
FROM Albümler
JOIN Şarkılar ON Albümler.albüm_id = Şarkılar.albüm_id
JOIN Sanatçılar ON Şarkılar.sanatçı_id = Sanatçılar.sanatçı_id
WHERE Sanatçılar.sanatçı_adı = 'Sezen Aksu'--hangi sanat şarkıların sıralanmasını istiyorsak o sanatçının ismini buraya yazacağız 
ORDER BY Albümler.albüm_adı;
--3.Kullanıcının yeni çalma listesi oluşturarak çalma listesine şarkı eklemesini sağlayan sql kodu
DECLARE @çalma_listesi_şarkısı_id INT;
SET @çalma_listesi_şarkısı_id =1;
DECLARE @şarkı_id INT;
SET @şarkı_id = 1;
INSERT INTO ÇalmaListeleri (liste_id, liste_adı, kullanıcı_id)
VALUES (11, 'Pop Hits', 9);
DECLARE @liste_id INT;
SET @liste_id = 11;
INSERT INTO ÇalmaListesiŞarkıları (çalma_listesi_şarkısı_id,liste_id, şarkı_id)
VALUES (@çalma_listesi_şarkısı_id,@liste_id, @şarkı_id);
--4.Verilen kullanıcı koduna göre o kullanıcıya ait çalma listelerini sıralayarak listeleyen sql kodu
DECLARE @kullanıcı_id  INT;
SET @kullanıcı_id  = 7;--burada  çalma listelerini sıranmak istenen kullanıcının idisini giriyoruz.
SELECT ÇalmaListeleri.liste_adı
FROM ÇalmaListeleri
WHERE ÇalmaListeleri.kullanıcı_id = @kullanıcı_id;
--5.En çok beğeni alan sanatçı ve o sanatçının en fazla yorum yapılan şarkısını gösteren sql kodu
SELECT
    Sanatçılar.sanatçı_adı AS en_cok_begenilen_sanatci,
    Şarkılar.şarkı_adı AS en_fazla_yorum_yapilan_sarki
FROM
    Sanatçılar
    INNER JOIN Şarkılar ON Sanatçılar.sanatçı_id = Şarkılar.sanatçı_id
    INNER JOIN Beğeniler ON Şarkılar.şarkı_id = Beğeniler.şarkı_id
    INNER JOIN Yorumlar ON Şarkılar.şarkı_id = Yorumlar.şarkı_id
GROUP BY
    Sanatçılar.sanatçı_id,
    Sanatçılar.sanatçı_adı,
    Şarkılar.şarkı_id,
    Şarkılar.şarkı_adı
HAVING
    COUNT(DISTINCT Beğeniler.beğeni_id) = (
        SELECT
            MAX(beğeni_sayısı)
        FROM
            (SELECT
                Sanatçılar.sanatçı_id,
                COUNT(DISTINCT Beğeniler.beğeni_id) AS beğeni_sayısı
            FROM
                Sanatçılar
                INNER JOIN Şarkılar ON Sanatçılar.sanatçı_id = Şarkılar.sanatçı_id
                INNER JOIN Beğeniler ON Şarkılar.şarkı_id = Beğeniler.şarkı_id
            GROUP BY
                Sanatçılar.sanatçı_id) AS beğeni_tablosu
    )
    AND COUNT(DISTINCT Yorumlar.yorum_id) = (
        SELECT
            MAX(yorum_sayısı)
        FROM
            (SELECT
                Sanatçılar.sanatçı_id,
                COUNT(DISTINCT Yorumlar.yorum_id) AS yorum_sayısı
            FROM
                Sanatçılar
                INNER JOIN Şarkılar ON Sanatçılar.sanatçı_id = Şarkılar.sanatçı_id
                INNER JOIN Yorumlar ON Şarkılar.şarkı_id = Yorumlar.şarkı_id
            GROUP BY
                Sanatçılar.sanatçı_id) AS yorum_tablosu
    );--hepsini birkez beğendim o yüzden hepsi ekrana geldi
--6. Beğeni sayısı 10’un üzerinde en az 5 şarkısı olan sanatçıyı popüler sanatçı olarak gösteren sql kodunu 
SELECT
    Sanatçılar.sanatçı_adı AS popüler_sanatçı
FROM
    Sanatçılar
    INNER JOIN Şarkılar ON Sanatçılar.sanatçı_id = Şarkılar.sanatçı_id
    INNER JOIN Beğeniler ON Şarkılar.şarkı_id = Beğeniler.şarkı_id
GROUP BY
    Sanatçılar.sanatçı_id,
    Sanatçılar.sanatçı_adı
HAVING
    COUNT(DISTINCT Şarkılar.şarkı_id) >= 5
    AND COUNT(DISTINCT Beğeniler.beğeni_id) > 10;--her sanatçıya bir şarkı tek ekledim.....
--7. En çok yorum ve beğenisi olan ilk 5 şarkının bilgilerini ve beğeni ve yorum sayılarını listeleyen kodu
SELECT TOP 5
    s.şarkı_id,
    s.şarkı_adı,
    COUNT(b.beğeni_id) AS beğeni_sayısı,
    COUNT(y.yorum_id) AS yorum_sayısı
FROM
    Şarkılar s
    LEFT JOIN Beğeniler b ON s.şarkı_id = b.şarkı_id
    LEFT JOIN Yorumlar y ON s.şarkı_id = y.şarkı_id
GROUP BY
    s.şarkı_id,
    s.şarkı_adı
ORDER BY
    beğeni_sayısı DESC,
    yorum_sayısı DESC;--her bir şarkıyı bir kere beğendim kayıt ekleme yaparken o yüzden çıktı ona göre çıkıyor....
--8. En çok paylaşım yapılan çalma listesinde aynı sanatçıya ait şarkıları gruplandırarak listeleyen sql kodunu 
SELECT Sanatçılar.sanatçı_adı, Şarkılar.şarkı_adı
FROM Sanatçılar
INNER JOIN Şarkılar ON Sanatçılar.sanatçı_id = Şarkılar.sanatçı_id
INNER JOIN (SELECT Şarkılar.sanatçı_id, COUNT(*) AS cnt FROM Şarkılar GROUP BY Şarkılar.sanatçı_id) AS t ON t.sanatçı_id = Sanatçılar.sanatçı_id
ORDER BY t.cnt DESC;
--9. Yeni şarkı ekleme işlemini gerçekleştiren bir stored procedure oluşturunuz. Bu stored procedure,kullanıcıdan şarkı bilgilerini alarak Şarkılar tablosuna yeni bir kayıt ekleyen sql kodu
CREATE PROCEDURE yeniSarkiEkleme
@SarkiAdi VARCHAR(100),
@Sure TIME,
@YayinTarihi DATE,
@AlbumID INT,
@SanatciID INT,
@TurID INT
AS
BEGIN
INSERT INTO Şarkılar (şarkı_adı, süre, yayın_tarihi, albüm_id, sanatçı_id, tür_id)
VALUES (@SarkiAdi, @Sure, @YayinTarihi, @AlbumID, @SanatciID, @TurID)
END
--bu sql sorgu düzgün bir şekilde çalıştı ancak tablolar arası ilişkilerden dolayı ekleme olmadı...
--10.Kullanıcının çalma listesine şarkı eklemesini sağlayan bir stored procedure oluşturunuz. Çalma listesine şarkı eklenirken üyelik bilgilerinin kontrolünü sağlan sql kodu
CREATE PROCEDURE AddSongToPlaylist(
  @liste_id INT,
  @şarkı_id INT,
  @kullanıcı_id INT
)
AS
BEGIN
  -- Kullanıcının üyelik tipini ve şarkı sınırlamasını kontrol et
  DECLARE @üyelik_tipi VARCHAR(100);
  DECLARE @şarkı_sınırlama INT;
  
  SELECT @üyelik_tipi = ü.üyelik_tipi, @şarkı_sınırlama = ü.şarkı_sınırlama
  FROM Üyelik ü
  WHERE ü.kullanıcı_id = @kullanıcı_id;
  
  -- Kullanıcının üyeliği kontrol edilir
  IF (@üyelik_tipi IS NULL)
  BEGIN
    RAISERROR('Kullanıcının üyeliği bulunamadı.', 16, 1);
    RETURN;
  END;
  
  -- Şarkı sınırlamasını kontrol et
  IF (@şarkı_sınırlama IS NOT NULL)
  BEGIN
    -- Kullanıcının çalma listesindeki şarkı sayısını al
    DECLARE @şarkı_sayısı INT;
    
    SELECT @şarkı_sayısı = COUNT(*) 
    FROM ÇalmaListeleri c
    JOIN Favoriler f ON c.liste_id = f.liste_id
    WHERE c.liste_id = @liste_id
    AND f.kullanıcı_id = @kullanıcı_id;
    
    IF (@şarkı_sayısı >= @şarkı_sınırlama)
    BEGIN
      RAISERROR('Şarkı sınırlamasına ulaşıldı.', 16, 1);
      RETURN;
    END;
  END;
  
  -- Şarkıyı çalma listesine ekle
  INSERT INTO Favoriler (kullanıcı_id, şarkı_id)
  VALUES (@kullanıcı_id, @şarkı_id);
  
  PRINT 'Şarkı çalma listesine eklendi.';
END;
--11. Yeni bir şarkı albümü veya sanatçısı eklenirken, ilgili tablolarda otomatik güncellemeler yapacak bir trigger oluşturduğum sql kodu
CREATE TRIGGER yeni_albüm_trigger
ON Albümler
AFTER INSERT
AS
BEGIN
  -- Eklenen albümün sanatçısı var mı kontrol edilir
  IF NOT EXISTS (SELECT 1 FROM Sanatçılar WHERE sanatçı_id = (SELECT sanatçı_id FROM inserted))
  BEGIN
    INSERT INTO Sanatçılar (sanatçı_id, sanatçı_adı, doğum_tarihi, ülke)
    SELECT 11, 'Yeni Sanatçı', '2000-01-01', 'Bilinmiyor'
    FROM inserted;
  END;
END;
CREATE TRIGGER yeni_sanatçı_trigger
ON Sanatçılar
AFTER INSERT
AS
BEGIN
  -- Eklenen sanatçının albümü var mı kontrol edilir
  DECLARE @albüm_var INT;
  SELECT @albüm_var = COUNT(*)
  FROM Albümler
  WHERE albüm_id IN (SELECT albüm_id FROM inserted);
  
  -- Albüm yoksa Albümler tablosuna eklenir
  IF @albüm_var = 0
  BEGIN
    INSERT INTO Albümler (albüm_id, albüm_adı, yayın_tarihi, kapak_resmi)
    SELECT 11, 'Yeni Albüm', '2000-01-01', 'kapak_resmi.jpg'
    FROM inserted;
  END
END;
--12. Bir kullanıcının çalma listesinden şarkı silindiğinde, ilgili tablolarda otomatik güncellemeler yapacak bir trigger oluşturulan sql kodu
-- Çalma listesinden şarkı silindiğinde tetikleyici (trigger)
CREATE TRIGGER silinen_sarki_guncelle
ON ÇalmaListesiŞarkıları
AFTER DELETE
AS
BEGIN
  -- Silinen şarkının bilgilerini al
  DECLARE @silinen_sarki_id INT;
  SELECT @silinen_sarki_id = 1;
  -- Şarkının beğenilerini ve yorumlarını sil
  DELETE FROM Beğeniler WHERE şarkı_id = @silinen_sarki_id;
  DELETE FROM Yorumlar WHERE şarkı_id = @silinen_sarki_id;
  -- Şarkının favorilerini sil
  DELETE FROM Favoriler WHERE şarkı_id = @silinen_sarki_id;
  -- Şarkının çalma listelerinden silinmesi
  UPDATE ÇalmaListesiŞarkıları SET  şarkı_id = NULL WHERE  şarkı_id = @silinen_sarki_id;
END;
--13. Kullanıcıların şarkıları beğenmesini ve favorilere eklemesini sağlayan sql kodunu yazınız. Kullanıcılar, beğendikleri şarkıları favorilere ekleyebilir ve sonradan bu favori şarkılara erişebilen sql kodu
-- Şarkıyı beğenme (Like) işlemi için SQL kodu
INSERT INTO Beğeniler (kullanıcı_id, şarkı_id, beğeni_durumu)
VALUES (3, 1, 'Beğendi');
-- Şarkıyı favorilere ekleme işlemi için SQL kodu
INSERT INTO Favoriler (kullanıcı_id, şarkı_id)
VALUES (3, 1);
/*kodu uygularken, kullanıcı_id_değeri ve şarkı_id_değeri yerine ilgili kullanıcı 
ve şarkının id değerlerini kullanmamız gerekmektedir. Örneğin, kullanıcı_id_değeri yerine kullanıcının gerçek id değeri 
ve şarkı_id_değeri yerine beğenilen/favorilere eklenen şarkının gerçek ID değeri kullanılmalıdır.
*/
--14. Şarkılara en çok yorum yazan ve beğeni yapan kullanıcıya 1 ay süre ile Premium üyelik hakkı tanımlayan sql kodunu 
UPDATE Üyelik
SET üyelik_tipi = 'Premium', şarkı_sınırlama = 0
WHERE kullanıcı_id = (
  SELECT kullanıcı_id
  FROM (
    SELECT kullanıcı_id, ROW_NUMBER() OVER (ORDER BY yorum_sayısı DESC) AS sıra
    FROM (
      SELECT kullanıcı_id, COUNT(*) AS yorum_sayısı
      FROM Yorumlar
      GROUP BY kullanıcı_id
    ) AS yorum_sayıları
  ) AS en_cok_yorum_yapan
  WHERE sıra = 1
)
AND kullanıcı_id = (
  SELECT kullanıcı_id
  FROM (
    SELECT kullanıcı_id, ROW_NUMBER() OVER (ORDER BY beğeni_sayısı DESC) AS sıra
    FROM (
      SELECT kullanıcı_id, COUNT(*) AS beğeni_sayısı
      FROM Beğeniler
      GROUP BY kullanıcı_id
    ) AS beğeni_sayıları
  ) AS en_cok_begeni_yapan
  WHERE sıra = 1
);
--15.Kullanıcı bilgilerinin silinmesi işlemi denendiğinde bu işlemin ne zaman denendiğini gösteren trigger kodu
CREATE TRIGGER kullanıcı_silme_tetikleyici
ON Kullanıcılar
AFTER DELETE
AS
BEGIN
    INSERT INTO SilinenKullanıcılar (kullanıcı_id, silinme_tarihi)
    VALUES (5, GETDATE());
END;